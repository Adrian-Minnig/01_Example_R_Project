# unibeCols 0.0.2

* Removal of dependance on `ggplot2` and `forcats`

# unibeCols 0.0.1

* First version of the package
